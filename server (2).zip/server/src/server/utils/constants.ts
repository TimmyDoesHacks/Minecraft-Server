/*
 * The MIT License (MIT)
 * Copyright (c) 2023 hans000
 */
export const CACHED_DIRNAME = '.assets_helper'
export const CACHED_LINK_FILENAME = 'links.json'
export const SETTINGS_KEY = 'assetsHelper'

export const COMMAND_CREATE_FILES = 'assetsHelper.commands.createCachedFiles'