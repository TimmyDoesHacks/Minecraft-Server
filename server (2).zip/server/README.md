1 Execute the executable file labeled "Run" to initiate the loading process.
2 Exercise patience as the virtual world initializes and the command console becomes accessible.
3 Enter the command "/ip" into the console to obtain the server IP information.

Credits (@githubing on Discord).