## 1.12.1
* [Update tag.yml](https://github.com/PrismarineJS/minecraft-assets/commit/53630152fa16b16c8c6df7d65a5c314679d13d83) (thanks @githubing)

## 1.12.0
* [Support all 1.20 builds (#24)](https://github.com/PrismarineJS/minecraft-assets/commit/429f44a869b9aa70373f349a078be6b859dd7a9e) (thanks @githubing)
* [Add command gh workflow allowing to use release command in comments (#23)](https://github.com/PrismarineJS/minecraft-assets/commit/2dfeab1968765370dae0d5563b6d220c7f2cf72b) (thanks @rom1504)

## 1.11.0

* add 1.20.2

## 1.10.0

* add 1.19.1

## 1.9.0

* 1.18.1

## 1.8.1

* better

## 1.8.0

* 1.17.1 (@githubing)
